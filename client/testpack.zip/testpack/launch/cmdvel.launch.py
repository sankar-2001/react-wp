import os

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource


def generate_launch_description():


ros2 launch rosbridge_server rosbridge_websocket_launch.xml
    rosbridge_server = ExecuteProcess(
        cmd=[[
            'ros2 ',
	    'launch ',
	    'rosbridge_server ',
	    'rosbridge_websocket_launch.xml '
        ]],
        shell=True
    )
    test-topic-1 = ExecuteProcess(
        cmd=[[
            'ros2 ',
            'topic ',
            'pub ',
	    '/listener ',
	    'std_msgs/String ',
            '"data: 'hello'"'
        ]],
        shell=True
    )

